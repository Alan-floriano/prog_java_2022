package br.com.senaisp.aula02;

public class ExerciciosAula02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        // Primeira express�o 
		double dblConta = 2.00 / 5.00;
		System.out.println("Resultado da primeira express�o � : "+ dblConta);
		// Segunda express�o
		double dblEqc1 = ((2.00 / 3.00) + 10.0);
		System.out.println("Resultado da segunda express�o � : "+ dblEqc1);
		// Terceira express�o
		double dblEqc2 = (1.00 / 5.00) * (3.00 / 4.00) + 5.00;
		System.out.println("Resultado da terceira express�o � : "+ dblEqc2);
		
	}

}
